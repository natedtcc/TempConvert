package com.nnasteff.tempconvert;

import android.text.Editable;

import java.text.DecimalFormat;

public class TempConverter {

    private double tempFar;
    private double tempCel;
    private double tempIn;
    private boolean tempSelect;
    DecimalFormat formatter = new DecimalFormat("#0.0");

    public TempConverter(){
        tempIn = 79;
        tempSelect = true;
    }

    public double getTempIn() {
        return tempIn;
    }

    public void setTempIn(String t) {
        this.tempIn = Double.parseDouble(t);
    }


    public String getTemps() {
        tempCel = (tempIn - 32) * (5.0/9.0);
        tempFar = tempIn * (9.0/5.0) + 32;
        if(tempSelect)
            return formatter.format(tempFar) + "°F";
        else
            return formatter.format(tempCel) + "°C";
    }

    public void setTempSelect(boolean tempSelect) {
        this.tempSelect = tempSelect;
    }

}
