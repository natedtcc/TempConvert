package com.nnasteff.tempconvert;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.widget.EditText;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    public static TempConverter tempCalc = new TempConverter();
    private EditText tempET;
    private Button buttonFar;
    private Button buttonCel;
    private String tempIn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButtonHandler bh = new ButtonHandler();
        tempET = (EditText) findViewById(R.id.temp);
        buttonFar = (Button) findViewById(R.id.fahrenheit);
        buttonCel = (Button) findViewById(R.id.celsius);
        buttonFar.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                tempCalc.setTempIn(tempET.getText().toString());
                tempCalc.setTempSelect(true);
                startActivity(new Intent(MainActivity.this, CalcActivity.class));
            }
        });

        buttonCel.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                tempCalc.setTempIn(tempET.getText().toString());
                tempCalc.setTempSelect(false);
                startActivity(new Intent(MainActivity.this, CalcActivity.class));
           }
        });

    }

    // Implement check logic into ButtonHandler

    public void showTemp(View v){
        Intent myintent = new Intent (this, CalcActivity.class);
        this.startActivity(myintent);
    }


    private class ButtonHandler implements View.OnClickListener {
        public void onClick(View v) {

        }
    }
}
