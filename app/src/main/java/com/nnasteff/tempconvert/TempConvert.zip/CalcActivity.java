package com.nnasteff.tempconvert;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;


public class CalcActivity extends AppCompatActivity {

    private TextView tempOut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calc);
        tempOut = (TextView) findViewById(R.id.temp);
        tempOut.setText(String.valueOf(MainActivity.tempCalc.getTemps()));
    }
}
